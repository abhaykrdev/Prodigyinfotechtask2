import 'package:flutter/material.dart';


Color tdRed=const Color(0xFFDA4040);
Color tdBlue = const Color(0xFF5F52EE);
Color tdBlack = const Color(0xFF3A3A3A);
Color tdGrey = const Color(0xFF717171);
Color tdBGColor=const Color(0xFFEEEFF5);